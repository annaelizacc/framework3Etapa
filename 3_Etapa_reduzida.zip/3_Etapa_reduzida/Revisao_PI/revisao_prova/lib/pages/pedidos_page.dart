import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/pedido.dart';
import '../viewmodels/login_viewmodel.dart';
import '../viewmodels/pedido_viewmodel.dart';
import 'login_page.dart';

class PedidosPage extends StatefulWidget {
  const PedidosPage({super.key});

  @override
  State<PedidosPage> createState() => _PedidosPageState();
}

class _PedidosPageState extends State<PedidosPage> {
  final _clienteController = TextEditingController();
  final _pratoController = TextEditingController();
  final _quantidadeController = TextEditingController();
  final _valorController = TextEditingController();

  @override
  void initState() {
    super.initState();
    // Carrega os pedidos salvos no SQLite ao abrir a tela.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<PedidoViewModel>().carregarPedidos();
    });
  }

  Future<void> _salvar() async {
    final sucesso = await context.read<PedidoViewModel>().adicionarPedido(
          cliente: _clienteController.text,
          prato: _pratoController.text,
          quantidadeTexto: _quantidadeController.text,
          valorTexto: _valorController.text,
        );

    if (sucesso) {
      _clienteController.clear();
      _pratoController.clear();
      _quantidadeController.clear();
      _valorController.clear();
    }
  }

  void _sair() {
    context.read<PedidoViewModel>().limpar();
    context.read<LoginViewModel>().sair();
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const LoginPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final viewModel = context.watch<PedidoViewModel>();
    final usuario = context.watch<LoginViewModel>().usuarioLogado;

    return Scaffold(
      appBar: AppBar(
        title: Text('Pedidos${usuario != null ? ' - ${usuario.nome}' : ''}'),
        actions: [
          IconButton(
            tooltip: 'Sair',
            icon: const Icon(Icons.logout),
            onPressed: _sair,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _clienteController,
              decoration: const InputDecoration(
                labelText: 'Cliente',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _pratoController,
              decoration: const InputDecoration(
                labelText: 'Prato',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _quantidadeController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'Quantidade',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: _valorController,
                    keyboardType: const TextInputType.numberWithOptions(
                      decimal: true,
                    ),
                    decoration: const InputDecoration(
                      labelText: 'Valor unitário',
                      prefixText: 'R\$ ',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
              ],
            ),
            if (viewModel.erro != null)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(
                  viewModel.erro!,
                  style: TextStyle(color: Theme.of(context).colorScheme.error),
                ),
              ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _salvar,
                child: const Text('Cadastrar pedido'),
              ),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: viewModel.pedidos.isEmpty
                  ? const Center(child: Text('Nenhum pedido registrado.'))
                  : ListView.builder(
                      itemCount: viewModel.pedidos.length,
                      itemBuilder: (context, index) {
                        final pedido = viewModel.pedidos[index];
                        return _PedidoCard(
                          pedido: pedido,
                          onFinalizar: () => viewModel.finalizarPedido(pedido),
                          onExcluir: () => viewModel.excluirPedido(pedido),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _clienteController.dispose();
    _pratoController.dispose();
    _quantidadeController.dispose();
    _valorController.dispose();
    super.dispose();
  }
}

class _PedidoCard extends StatelessWidget {
  final Pedido pedido;
  final VoidCallback onFinalizar;
  final VoidCallback onExcluir;

  const _PedidoCard({
    required this.pedido,
    required this.onFinalizar,
    required this.onExcluir,
  });

  @override
  Widget build(BuildContext context) {
    final grande = pedido.classificacao == 'PEDIDO GRANDE';

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Cliente: ${pedido.cliente} | Prato: ${pedido.prato}',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 4),
            Text(
              'Quantidade: ${pedido.quantidade} | Total: ${pedido.totalFormatado}',
            ),
            const SizedBox(height: 4),
            Text(
              'Classificação: ${pedido.classificacao}',
              style: TextStyle(
                fontWeight: FontWeight.w600,
                color: grande ? Colors.deepOrange : Colors.blueGrey,
              ),
            ),
            Text(
              'Status: ${pedido.status}',
              style: TextStyle(
                color: pedido.finalizado ? Colors.green : Colors.orange,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                  onPressed: pedido.finalizado ? null : onFinalizar,
                  child: const Text('FINALIZAR'),
                ),
                TextButton(
                  onPressed: onExcluir,
                  style: TextButton.styleFrom(foregroundColor: Colors.red),
                  child: const Text('EXCLUIR'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
