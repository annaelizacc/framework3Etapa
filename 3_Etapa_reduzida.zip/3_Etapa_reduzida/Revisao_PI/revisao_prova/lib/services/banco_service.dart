import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

import '../models/pedido.dart';
import '../models/usuario.dart';

/// Única camada que conversa diretamente com o SQLite.
class BancoService {
  Database? _db;

  Future<Database> _abrirBanco() async {
    if (_db != null) return _db!;

    final pasta = await getDatabasesPath();
    final caminho = join(pasta, 'the_bear.db');

    _db = await openDatabase(
      caminho,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE usuario (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            senha TEXT NOT NULL
          )
        ''');

        await db.execute('''
          CREATE TABLE pedido (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente TEXT NOT NULL,
            prato TEXT NOT NULL,
            quantidade INTEGER NOT NULL,
            valor_unitario REAL NOT NULL,
            status TEXT NOT NULL
          )
        ''');
      },
    );
    return _db!;
  }

  // ================= USUÁRIOS =================

  Future<void> inserirUsuario(Usuario usuario) async {
    final db = await _abrirBanco();
    await db.insert('usuario', {
      'nome': usuario.nome,
      'email': usuario.email,
      'senha': usuario.senha,
    });
  }

  Future<bool> emailJaCadastrado(String email) async {
    final db = await _abrirBanco();
    final dados = await db.query(
      'usuario',
      where: 'email = ?',
      whereArgs: [email],
      limit: 1,
    );
    return dados.isNotEmpty;
  }

  /// Retorna o usuário se as credenciais forem válidas, senão null.
  Future<Usuario?> autenticar(String email, String senha) async {
    final db = await _abrirBanco();
    final dados = await db.query(
      'usuario',
      where: 'email = ? AND senha = ?',
      whereArgs: [email, senha],
      limit: 1,
    );
    if (dados.isEmpty) return null;
    return Usuario.fromMap(dados.first);
  }

  // ================= PEDIDOS =================

  Future<void> inserirPedido(Pedido pedido) async {
    final db = await _abrirBanco();
    await db.insert('pedido', {
      'cliente': pedido.cliente,
      'prato': pedido.prato,
      'quantidade': pedido.quantidade,
      'valor_unitario': pedido.valorUnitario,
      'status': pedido.status,
    });
  }

  Future<List<Pedido>> listarPedidos() async {
    final db = await _abrirBanco();
    final dados = await db.query('pedido', orderBy: 'id DESC');
    return dados.map((item) => Pedido.fromMap(item)).toList();
  }

  Future<void> atualizarStatus(int id, String status) async {
    final db = await _abrirBanco();
    await db.update(
      'pedido',
      {'status': status},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<void> excluirPedido(int id) async {
    final db = await _abrirBanco();
    await db.delete(
      'pedido',
      where: 'id = ?',
      whereArgs: [id],
    );
  }
}
