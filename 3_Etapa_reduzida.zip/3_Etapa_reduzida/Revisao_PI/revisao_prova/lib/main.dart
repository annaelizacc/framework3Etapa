import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'pages/login_page.dart';
import 'services/banco_service.dart';
import 'viewmodels/login_viewmodel.dart';
import 'viewmodels/pedido_viewmodel.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Uma única instância do Service é compartilhada pelas ViewModels.
    final service = BancoService();

    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => LoginViewModel(service)),
        ChangeNotifierProvider(create: (_) => PedidoViewModel(service)),
      ],
      child: MaterialApp(
        title: 'The Bear',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepOrange),
          useMaterial3: true,
        ),
        home: const LoginPage(),
      ),
    );
  }
}
