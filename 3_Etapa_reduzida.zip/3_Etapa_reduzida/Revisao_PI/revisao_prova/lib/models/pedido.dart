class Pedido {
  static const String statusPendente = 'Pendente';
  static const String statusFinalizado = 'Finalizado';

  final int? id;
  final String cliente;
  final String prato;
  final int quantidade;
  final double valorUnitario;
  final String status;

  Pedido({
    this.id,
    required this.cliente,
    required this.prato,
    required this.quantidade,
    required this.valorUnitario,
    this.status = statusPendente, // todo novo pedido nasce como Pendente
  });

  /// total = quantidade × valor_unitario
  double get total => quantidade * valorUnitario;

  /// Quantidade < 5 -> PEDIDO NORMAL | Quantidade >= 5 -> PEDIDO GRANDE
  String get classificacao =>
      quantidade >= 5 ? 'PEDIDO GRANDE' : 'PEDIDO NORMAL';

  bool get finalizado => status == statusFinalizado;

  /// Valor total formatado, ex: R$ 50,00
  String get totalFormatado => formatarMoeda(total);

  static String formatarMoeda(double valor) {
    return 'R\$ ${valor.toStringAsFixed(2).replaceAll('.', ',')}';
  }

  Pedido copyWith({String? status}) {
    return Pedido(
      id: id,
      cliente: cliente,
      prato: prato,
      quantidade: quantidade,
      valorUnitario: valorUnitario,
      status: status ?? this.status,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'cliente': cliente,
      'prato': prato,
      'quantidade': quantidade,
      'valor_unitario': valorUnitario,
      'status': status,
    };
  }

  factory Pedido.fromMap(Map<String, dynamic> map) {
    return Pedido(
      id: map['id'] as int?,
      cliente: map['cliente'] as String,
      prato: map['prato'] as String,
      quantidade: map['quantidade'] as int,
      valorUnitario: (map['valor_unitario'] as num).toDouble(),
      status: map['status'] as String,
    );
  }
}
