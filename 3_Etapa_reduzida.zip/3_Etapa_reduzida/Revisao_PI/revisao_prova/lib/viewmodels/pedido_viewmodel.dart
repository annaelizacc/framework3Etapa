import 'package:flutter/material.dart';

import '../models/pedido.dart';
import '../services/banco_service.dart';

class PedidoViewModel extends ChangeNotifier {
  final BancoService _service;

  PedidoViewModel(this._service);

  List<Pedido> pedidos = [];
  String? erro;

  Future<void> carregarPedidos() async {
    pedidos = await _service.listarPedidos();
    notifyListeners();
  }

  /// Valida os dados, cria o pedido (status Pendente) e salva no SQLite.
  /// Retorna true se o pedido foi cadastrado.
  Future<bool> adicionarPedido({
    required String cliente,
    required String prato,
    required String quantidadeTexto,
    required String valorTexto,
  }) async {
    cliente = cliente.trim();
    prato = prato.trim();
    final quantidade = int.tryParse(quantidadeTexto.trim());
    final valor = double.tryParse(valorTexto.trim().replaceAll(',', '.'));

    if (cliente.isEmpty || prato.isEmpty) {
      erro = 'Informe o cliente e o prato.';
      notifyListeners();
      return false;
    }
    if (quantidade == null || quantidade <= 0) {
      erro = 'Informe uma quantidade válida.';
      notifyListeners();
      return false;
    }
    if (valor == null || valor <= 0) {
      erro = 'Informe um valor unitário válido.';
      notifyListeners();
      return false;
    }

    erro = null;
    await _service.inserirPedido(
      Pedido(
        cliente: cliente,
        prato: prato,
        quantidade: quantidade,
        valorUnitario: valor,
      ),
    );
    await carregarPedidos();
    return true;
  }

  Future<void> finalizarPedido(Pedido pedido) async {
    if (pedido.id == null) return;
    await _service.atualizarStatus(pedido.id!, Pedido.statusFinalizado);
    await carregarPedidos();
  }

  Future<void> excluirPedido(Pedido pedido) async {
    if (pedido.id == null) return;
    await _service.excluirPedido(pedido.id!);
    await carregarPedidos();
  }

  void limpar() {
    pedidos = [];
    erro = null;
    notifyListeners();
  }
}
