import 'package:flutter/material.dart';

import '../models/usuario.dart';
import '../services/banco_service.dart';

class LoginViewModel extends ChangeNotifier {
  final BancoService _service;

  LoginViewModel(this._service);

  Usuario? usuarioLogado;
  String? erro;
  bool carregando = false;

  void limparErro() {
    erro = null;
    notifyListeners();
  }

  // ================= LOGIN =================

  /// Retorna true se as credenciais forem válidas.
  Future<bool> entrar(String email, String senha) async {
    email = email.trim();

    if (email.isEmpty || senha.isEmpty) {
      erro = 'Informe o e-mail e a senha.';
      notifyListeners();
      return false;
    }

    carregando = true;
    erro = null;
    notifyListeners();

    final usuario = await _service.autenticar(email, senha);

    carregando = false;
    if (usuario == null) {
      erro = 'E-mail ou senha inválidos.';
      notifyListeners();
      return false;
    }

    usuarioLogado = usuario;
    notifyListeners();
    return true;
  }

  void sair() {
    usuarioLogado = null;
    erro = null;
    notifyListeners();
  }

  // ================= CADASTRO =================

  /// Retorna true se o usuário foi cadastrado.
  Future<bool> cadastrar(String nome, String email, String senha) async {
    nome = nome.trim();
    email = email.trim();

    if (nome.isEmpty || email.isEmpty || senha.isEmpty) {
      erro = 'Preencha todos os campos.';
      notifyListeners();
      return false;
    }

    if (!email.contains('@')) {
      erro = 'Informe um e-mail válido.';
      notifyListeners();
      return false;
    }

    carregando = true;
    erro = null;
    notifyListeners();

    if (await _service.emailJaCadastrado(email)) {
      carregando = false;
      erro = 'Este e-mail já está cadastrado.';
      notifyListeners();
      return false;
    }

    await _service.inserirUsuario(
      Usuario(nome: nome, email: email, senha: senha),
    );

    carregando = false;
    notifyListeners();
    return true;
  }
}
