import 'package:flutter/material.dart';

class CadastroPage extends StatefulWidget{
 const CadastroPage({super.key});
 @override
 State<CadastroPage> createState() => _CadastroPageState();
}

class _CadastroPageState extends State<CadastroPage>{
  final nome = 
}