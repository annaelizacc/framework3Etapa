import 'package:firebase_auth/firebase_auth.dart';

class AuthService {
  //INSTANCIA PRINCIPAL DO FIREBASE - DESCOBRIR QUEM ESTA AUTENTICANDO
  final FirebaseAuth _auth = FirebaseAuth.instance;

  Future<void> entrarComGoogle() async {
    //DEFINE QUE  O MÉTODO DE AUTENTICAÇÃO  SERÁ GOOGLE
    final GoogleAuthProvider provider = GoogleAuthProvider();

   //FAZ O GOOGLE MOSTRAR A TELA PARA ESCOLHER
    provider.setCustomParameters({
      'prompt': 'select_account',
    });

    await _auth.signInWithPopup(provider);
  }

  Future<void> sair() async {
    await _auth.signOut();
  }

  Future<void> trocarConta() async {
    await _auth.signOut();

    final GoogleAuthProvider provider = GoogleAuthProvider();

    provider.setCustomParameters({
      'prompt': 'select_account',
    });

    await _auth.signInWithPopup(provider);
  }
}
