import 'package:atividade_listafilmes/models/filme.dart';
import 'package:atividade_listafilmes/services/filme_service.dart';
import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';

import '../models/filme.dart';

class FilmeViewmodel extends ChangeNotifier {
  
  final FilmeService service = FilmeService();

  List<Filme> filmes = [];

  Future<void> carregarFilmes() async{
    filmes = await service.listarFilmes();

    notifyListeners();
  }

  Future<void> adicionarFilmes(String titulo)async{

    if(titulo.isEmpty){//impede cadastros vazios
      return;
    }
   
   final filme = Filme(titulo: titulo);

   await service.inserirFilmes(filme);
   //depois de aslvar, busca novamente
   await carregarFilmes();

  }

  Future<void> alterarStatus (Filme filme)async{

   filme.assistido = !filme.assistido;

   await service.atualizarStatus(filme);

   await carregarFilmes();
  }
}
