import 'package:path/path.dart';

import 'package:sqflite/sqflite.dart';

import '../models/filme.dart';

class FilmeService {

Future<Database> abrirBanco() async {
  //DESCOBRE ONDE O DISPOSITIVO PERMITE SALVAR BANCO DE DADOS
  final caminhoBanco = await getDatabasesPath();

  print("LOCAL DO BANCO $caminhoBanco");

//JUNTA A PASTA ENCONTRADA COM NOME DO ARQUIVO
  final caminho = join(caminhoBanco, 'filmes.db');
  print("BANCO COMPLETO: $caminho");

  return openDatabase(
  caminho, 
  version: 1,
  
  onCreate: (db, version) async{
    await db.execute(
       '''
        CREATE TABLE filmes(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          titulo TEXT NOT NULL,
          assistido INTEGER NOT NULL
        )
       ''',
    );
  }
  );
}

Future <void> inserirFilmes(Filme filmes) async{
  final db = await abrirBanco();
  //insere no banco de dados
  await db.insert('filmes',{
    'titulos': filmes.titulo,
    'assistido':filmes.assistido ? 1:0,
   },
 );
}

Future<List<Filme>> listarFilmes() async{
  //abre o banco
  final db = await abrirBanco();

//Equivale a SELECT * FROM filmes 
  final dados = await db.query('filmes');


//O Sqlite devolve maps.
//Vamos transformar cada Map em um objeto filmes
  return dados.map((item){
    return Filme(
      id: item['id'] as int,
      titulo: item['titulo']as String,
      assistido :item['concluida'] == 1
    );
  }).toList();
}

Future <void> atualizarStatus(Filme filme) async{
  final db = await abrirBanco();

//atualiza um registro
  await db.update(
    'filmes',
     {'assitido':filme.assistido ? 1 : 0 },

//Definindo qual registro será atualizado
   where: 'id = ?',

   //id da filme q será atualizada
   whereArgs: [
    filme.id,
   ]

  );
}

}