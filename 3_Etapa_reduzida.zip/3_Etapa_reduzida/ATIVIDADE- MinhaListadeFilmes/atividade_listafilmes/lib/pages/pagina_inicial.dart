import 'package:atividade_listafilmes/viewmodels/filme_viewmodel.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../viewmodels/filme_viewmodel.dart';

class PaginaInicial extends StatefulWidget {
  const PaginaInicial({super.key});

  @override
  State<PaginaInicial> createState() {
    return _PaginaInicialState();
  }
}

class _PaginaInicialState extends State<PaginaInicial> {
  final TextEditingController controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final filmesViewModel = Provider.of<FilmeViewmodel>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Meus Filmes',
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Campo para digitar a filmes.
            TextField(
              controller: controller,
              decoration: const InputDecoration(
                labelText: 'Digite um filme',
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(
              height: 10,
            ),

            // Botão para cadastrar uma filme.
            ElevatedButton(
              onPressed: () {
                // Envia o texto para a ViewModel.
                filmesViewModel.adicionarFilmes(
                  controller.text,
                );

                // Limpa o campo depois de cadastrar.
                controller.clear();
              },
              child: const Text(
                'Salvar',
              ),
            ),

            const SizedBox(
              height: 20,
            ),

            // Expanded permite que a lista
            // ocupe o espaço restante.
            Expanded(
              child: ListView.builder(
                // Quantidade de filmes.
                itemCount: filmesViewModel.filmes.length,

                itemBuilder: (context, index) {
                  // Pega o filme da posição atual.
                  final filme = filmesViewModel.filmes[index];

                  return Card(
                    child: ListTile(
                      leading: CircleAvatar(
                        child: Text(
                          '${index + 1}',
                        ),
                      ),

                      // Mostra o título.
                      title: Text(
                        filme.titulo,

                        // Se estiver concluída,
                        // risca o texto.
                        style: TextStyle(
                          decoration: filme.assistido
                              ? TextDecoration.lineThrough
                              : TextDecoration.none,
                        ),
                      ),

                      // Permite marcar/desmarcar.
                      trailing: Checkbox(
                        value:  filme.assistido,
                        onChanged: (valor) {
                          filmesViewModel.alterarStatus(
                            filme,
                          );
                        },
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    controller.dispose();

    super.dispose();
  }
}
