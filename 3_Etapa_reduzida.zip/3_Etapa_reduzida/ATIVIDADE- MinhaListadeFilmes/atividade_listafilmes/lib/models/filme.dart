import 'package:flutter/material.dart';

class Filme{
  int? id;
  String titulo;
  bool assistido;

  Filme({
    this.id,
    required this.titulo,
    this.assistido = false,
  });

}