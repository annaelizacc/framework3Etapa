import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:device_preview/device_preview.dart';
import 'package:provider/provider.dart';
import 'package:sqflite/sqflite.dart';
import 'pages/pagina_inicial.dart';
import 'viewmodels/filme_viewmodel.dart';
import 'package:sqflite_common_ffi_web/sqflite_ffi_web.dart';

void main() async {
  // 1. Garante que os componentes nativos do Flutter sejam inicializados antes do banco de dados
  WidgetsFlutterBinding.ensureInitialized();

  // 2. Altere de kIsWasm para kIsWeb para cobrir qualquer execução no navegador
  if (kIsWeb) {
    databaseFactory = databaseFactoryFfiWeb;
  }

  runApp(
    DevicePreview(
      builder: (context) => const MeuApp(),
    ),
  );
}

class MeuApp extends StatelessWidget {
  const MeuApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Disponibiliza a FilmeViewmodel
    // para os widgets abaixo.
    return ChangeNotifierProvider(
      create: (context) => FilmeViewmodel(),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,

        // Integra o MaterialApp ao DevicePreview.
        builder: DevicePreview.appBuilder,

        locale: DevicePreview.locale(context),

        home: const PaginaInicial(),
      ),
    );
  }
}
