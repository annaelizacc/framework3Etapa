package com.example.atividade_listafilmes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
