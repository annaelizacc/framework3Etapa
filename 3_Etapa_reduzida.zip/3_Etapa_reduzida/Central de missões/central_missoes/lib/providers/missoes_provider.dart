
import 'package:flutter/material.dart';
import '../model/missoes.dart';
import '../services/missoes_service.dart';

class MissoesProvider extends ChangeNotifier {
  final MissoesService _service = MissoesService();

  List<Missao> missoes = [];

  bool carregando = true;
  MissoesProvider() {
    carregarMissao();
  }

  void carregarMissao() {
    _service.listarMissao().listen((lista) {
      missoes = lista;

      carregando = false;

      notifyListeners();
    });
  }

  Future<void> adicionar(String titulo, int pontos, String dificuldade) async {
    if (titulo.trim().isEmpty) {
      return;
    }

    await _service.adicionarMissao(titulo.trim(), dificuldade, pontos);
  }

  Future<void> alterarStatus(Missao missao) async {
    await _service.alterarStatus(missao);
  }

  Future<void> excluir(String id) async {
    await _service.excluirMissao(id);
  }
}
