import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter/services.dart';
import '../providers/missoes_provider.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController missaoController = TextEditingController();
  final TextEditingController missaoController2 = TextEditingController(); // Pontos
  final TextEditingController missaoController3 = TextEditingController(); // Dificuldade

  @override
  void dispose() {
    // CORRIGIDO: Limpa todos os três controllers da memória
    missaoController.dispose();
    missaoController2.dispose(); 
    missaoController3.dispose(); 
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Minhas Tarefas'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: missaoController,
              decoration: const InputDecoration(
                labelText: 'Digite uma tarefa',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10), 
            TextField(
              controller: missaoController2,
              keyboardType: TextInputType.number, 
              inputFormatters: [FilteringTextInputFormatter.digitsOnly], 
              decoration: const InputDecoration(
                labelText: 'Digite os pontos (número inteiro)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: missaoController3, // CORRIGIDO: Mudado de missaoController para missaoController3
              decoration: const InputDecoration(
                labelText: 'Digite a dificuldade',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () async {
                  final provider = context.read<MissoesProvider>();
                  
                  int? quantidade = int.tryParse(missaoController2.text);

                  // CORRIGIDO: Valida se o título E a dificuldade não estão vazios
                  if (quantidade != null && 
                      missaoController.text.isNotEmpty && 
                      missaoController3.text.isNotEmpty) {
                    
                    await provider.adicionar(
                      missaoController.text,   // Titulo
                      quantidade,              // Pontos (int)
                      missaoController3.text,  // Dificuldade
                    );

                    // CORRIGIDO: Limpa todos os campos da tela após o sucesso
                    missaoController.clear();
                    missaoController2.clear();
                    missaoController3.clear();
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Por favor, preencha todos os campos corretamente.'),
                      ),
                    );
                  }
                },
                child: const Text('Adicionar tarefa'),
              ),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: Consumer<MissoesProvider>(
                builder: (context, provider, child) {
                  if (provider.carregando) {
                    return const Center(
                      child: CircularProgressIndicator(),
                    );
                  }

                  if (provider.missoes.isEmpty) {
                    return const Center(
                      child: Text('Nenhuma tarefa cadastrada.'),
                    );
                  }

                  return ListView.builder(
                    itemCount: provider.missoes.length,
                    itemBuilder: (context, index) {
                      final missao = provider.missoes[index];

                      return Card(
                        child: ListTile(
                          leading: Checkbox(
                            value: missao.concluida,
                            onChanged: (valor) {
                              provider.alterarStatus(missao);
                            },
                          ),
                          title: Text(
                            missao.titulo,
                            style: TextStyle(
                              decoration: missao.concluida
                                  ? TextDecoration.lineThrough
                                  : TextDecoration.none,
                            ),
                          ),
                          subtitle: Text('Dificuldade: ${missao.dificuldade} | Pontos: ${missao.pontos}'), // Adicionado para exibir os novos campos no Card
                          trailing: IconButton(
                            icon: const Icon(Icons.delete),
                            onPressed: () {
                              provider.excluir(missao.id); 
                            },
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
