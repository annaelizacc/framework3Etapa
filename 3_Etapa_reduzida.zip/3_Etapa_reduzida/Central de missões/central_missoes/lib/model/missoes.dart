class Missao {
  String id;
  String titulo;
  String dificuldade;
  int pontos;
  bool concluida;

  Missao({
   required this.id,
    required this.titulo,
    required this.dificuldade,
    required this.pontos,
    this.concluida = false,
  });


 factory Missao.fromMap(String id, Map<String, dynamic> dados) {
    return Missao(
      id: id,
      titulo: dados['titulo'] ?? '',
      concluida: dados['concluida'] ?? false,
       pontos: dados['pontos'] ?? false,
        dificuldade: dados['dificuldade'] ?? false,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'titulo': titulo,
      'concluida': concluida,
      'pontos': pontos,
      'dificuldade': dificuldade
    };
  }
}