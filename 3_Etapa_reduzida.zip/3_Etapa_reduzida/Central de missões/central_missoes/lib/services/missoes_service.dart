import 'package:cloud_firestore/cloud_firestore.dart';

import '../model/missoes.dart';

class MissoesService {
  final FirebaseFirestore _firebase = FirebaseFirestore.instance;

  final String colecao = 'missoes';

  Stream<List<Missao>> listarMissao() {
    return _firebase.collection(colecao).snapshots().map((snapshot) {
      return snapshot.docs.map((documento) {
        return Missao.fromMap(
          documento.id,
          documento.data(),
        );
      }).toList();
    });
  }

  Future<void> adicionarMissao(String titulo, String dificuldade, int pontos) async {
    await _firebase.collection(colecao).add({
      'titulo': titulo,
      'concluida': false,
      'pontos': pontos,
      'dificuldade':dificuldade
    });
  }


  Future<void> alterarStatus(Missao missao) async {
    await _firebase.collection(colecao).doc(missao.id).update({
      'concluida': !missao.concluida,
    });
  }

  Future<void> excluirMissao(String id) async {
    await _firebase.collection(colecao).doc(id).delete();
  }
}
