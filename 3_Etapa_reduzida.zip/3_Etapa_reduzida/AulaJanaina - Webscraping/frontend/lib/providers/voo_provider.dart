import 'package:flutter/material.dart';
import '../services/voo_service.dart';

class VooProvider extends ChangeNotifier {
  final VooService _service = VooService();

  List<dynamic> _voos = [];
  List<dynamic> get voos => _voos;

  bool _carregando = false;
  bool get carregando => _carregando;

  String? _erro;
  String? get erro => _erro;

  Future<void> carregarVoos(String aeroporto, String tipo) async {
    _carregando = true;
    _erro = null;
    notifyListeners();

    try {
      _voos = await _service.buscarVoos(aeroporto, tipo);
    } catch (e) {
      _erro = e.toString();
    } finally {
      _carregando = false;
      notifyListeners();
    }
  }
}