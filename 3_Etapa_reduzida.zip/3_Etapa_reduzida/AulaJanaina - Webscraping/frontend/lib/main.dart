import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/voo_provider.dart';
import 'pages/tela_inicial.dart'; 

void main() {
  runApp(
    // O MultiProvider disponibiliza o VooProvider para TODAS as páginas do app
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => VooProvider()),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'App de Voos',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const VooPage(), // Define qual página abre primeiro
    );
  }
}