import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/voo_provider.dart';
import 'detalhes_voo_page.dart';

class VooPage extends StatefulWidget {
  const VooPage({super.key});

  @override
  State<VooPage> createState() => _VooPageState();
}

class _VooPageState extends State<VooPage> {
  final TextEditingController _icaoController = TextEditingController(text: 'SBGR');
  String _tipoSelecionado = 'chegadas';

  final List<String> _tiposVoos = ['chegadas', 'partidas', 'todos'];

  @override
  void initState() {
    super.initState();
    Future.microtask(() {
      _buscarVoos();
    });
  }

  void _buscarVoos() {
    final icao = _icaoController.text.trim().toUpperCase();
    if (icao.isNotEmpty) {
      context.read<VooProvider>().carregarVoos(icao, _tipoSelecionado);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Consulta de Voos')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _icaoController,
                        textCapitalization: TextCapitalization.characters,
                        decoration: const InputDecoration(
                          labelText: 'Código ICAO (Ex: SBGR)',
                          hintText: 'SBGR, SBSP, SBBR, SBCF',
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    ElevatedButton(
                      onPressed: _buscarVoos,
                      child: const Icon(Icons.search),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    const Text(
                      'Tipo: ',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: DropdownButton<String>(
                        isExpanded: true,
                        value: _tipoSelecionado,
                        items: _tiposVoos.map((String tipo) {
                          return DropdownMenuItem<String>(
                            value: tipo,
                            child: Text(tipo.toUpperCase()),
                          );
                        }).toList(),
                        onChanged: (novoTipo) {
                          if (novoTipo != null) {
                            setState(() {
                              _tipoSelecionado = novoTipo;
                            });
                            _buscarVoos();
                          }
                        },
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const Divider(),
          Expanded(
            child: Consumer<VooProvider>(
              builder: (context, provider, child) {
                if (provider.carregando) {
                  return const Center(child: CircularProgressIndicator());
                }

                if (provider.erro != null) {
                  return Center(
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Text(
                        'Erro ao carregar dados: ${provider.erro}',
                        textAlign: TextAlign.center,
                      ),
                    ),
                  );
                }

                if (provider.voos.isEmpty) {
                  return const Center(
                    child: Text('Nenhum voo encontrado para essa busca.'),
                  );
                }

                return ListView.builder(
                  itemCount: provider.voos.length,
                  itemBuilder: (context, index) {
                    final voo = provider.voos[index];
                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                      child: ListTile(
                        leading: Icon(
                          _tipoSelecionado == 'partidas'
                              ? Icons.flight_takeoff
                              : Icons.flight_land,
                          color: Colors.blue,
                        ),
                        title: Text('Voo: ${voo['numero'] ?? voo['voo'] ?? 'Sem número'}'),
                        subtitle: Text('Companhia: ${voo['companhia'] ?? voo['cia'] ?? 'N/A'}'),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => DetalhesVooPage(voo: voo),
                            ),
                          );
                        },
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}