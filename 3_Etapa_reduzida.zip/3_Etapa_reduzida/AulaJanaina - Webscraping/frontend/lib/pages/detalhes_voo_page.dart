import 'package:flutter/material.dart';

class DetalhesVooPage extends StatelessWidget {
  final Map<String, dynamic> voo;

  const DetalhesVooPage({super.key, required this.voo});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Voo ${voo['numero'] ?? voo['voo'] ?? ''}'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Companhia: ${voo['companhia'] ?? voo['cia'] ?? 'N/A'}',
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const Divider(),
                    const SizedBox(height: 8),
                    Text('Aeroporto: ${voo['aeroporto'] ?? 'N/A'}'),
                    Text('Origem: ${voo['origem'] ?? 'N/A'}'),
                    Text('Destino: ${voo['destino'] ?? 'N/A'}'),
                    Text('Horário Previsto: ${voo['horario_previsto'] ?? voo['horario'] ?? 'N/A'}'),
                    Text('Horário Real: ${voo['horario_real'] ?? 'N/A'}'),
                    Text('Status: ${voo['status'] ?? 'N/A'}'),
                    Text('Tipo: ${voo['tipo'] ?? 'N/A'}'),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}