import 'dart:convert';
import 'package:http/http.dart' as http;

class VooService {
  final String baseUrl = 'http://127.0.0.1:5001/api/voos';
  
  Future<List<dynamic>> buscarVoos(String aeroporto, String tipo) async {
   
    final url = Uri.parse('$baseUrl?aeroporto=$aeroporto&tipo=$tipo');

    final response = await http.get(url);

    if (response.statusCode == 200) {
      // 4. Converte o JSON recebido
      final List<dynamic> dados = jsonDecode(response.body);

      // 5. Devolve os dados para o Provider
      return dados;
    } else {
      throw Exception('Falha ao carregar dados da API: ${response.statusCode}');
    }
  }
}