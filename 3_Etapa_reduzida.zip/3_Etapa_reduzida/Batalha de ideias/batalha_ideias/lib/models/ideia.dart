import 'package:flutter/material.dart';

class Ideia{
  String id;
  String titulo;
String descricao;
String nomeAutor;
int qntVotos;

 Ideia({
required this.id,
 required this.titulo,
 required this.descricao,
 required this.nomeAutor,
 required this.qntVotos
 });
 
  }