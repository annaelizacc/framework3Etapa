import 'dart:ffi';

class Produto {
   int? id;
  String nome;
  String categoria;
  int quantidade;
  int preco;


Produto ({
this.id,
required this.nome,
required this.quantidade,
required this.categoria,
required this.preco
});
}
