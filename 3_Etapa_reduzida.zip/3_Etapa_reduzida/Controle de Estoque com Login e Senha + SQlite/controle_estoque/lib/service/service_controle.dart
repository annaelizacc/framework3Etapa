import 'package:controle_estoque/models/produto.dart';
import 'package:controle_estoque/models/usuario.dart';
import 'package:path/path.dart';

import 'package:sqflite/sqflite.dart';

import '../models/usuario.dart';

class TarefaService {

Future<Database> abrirBanco() async {
  //DESCOBRE ONDE O DISPOSITIVO PERMITE SALVAR BANCO DE DADOS
  final caminhoBanco = await getDatabasesPath();

  print("LOCAL DO BANCO $caminhoBanco");

//JUNTA A PASTA ENCONTRADA COM NOME DO ARQUIVO
  final caminho = join(caminhoBanco, 'controle.db');
  print("BANCO COMPLETO: $caminho");

  return openDatabase(
  caminho, 
  version: 1,
  
  onCreate: (db, version) async{
    await db.execute(
       '''
        CREATE TABLE usario(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          nome TEXT NOT NULL,
          senha TEXT NOT NULL,
          e_mail TEXT NOT NULL
        )
       ''');

       await db.execute('''
    CREATE TABLE produto (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nome TEXT NOT NULL,
      categoria TEXT NOT NULL,
      quantidade INTEGER NOT NULL,
      preco REAL NOT NULL
    )
  ''');
  }

  
  );
}
Future<void> inserirProduto(Produto produto) async {
  final db = await abrirBanco();
  await db.insert('usuario', {
    'nome': produto.nome,
    'id': produto.id,
    'categoria': produto.categoria,
    'quantidade': produto.quantidade,
    'preco': produto.preco, 
  });
}

Future<void> inserirUsuario(Usuario usuario) async {
  final db = await abrirBanco();
  await db.insert('usuario', {
    'nome': usuario.nome,
    'e_mail': usuario.email,
    'senha': usuario.senha, 
  });
}

Future<List<Usuario>> listarUsuario() async{
  //abre o banco
  final db = await abrirBanco();

//Equivale a SELECT * FROM tarefas 
  final dados = await db.query('usuario');


//O Sqlite devolve maps.
//Vamos transformar cada Map em um objeto tarefa
  return dados.map((item){
    return Usuario(
      id: item['id'] as int,
      nome: item['nome']as String,
      email :item['e_mail'] as String,
      senha :item['senha'] as String

    );
  }).toList();
}

Future<List<Produto>> listarProdutos() async{
  //abre o banco
  final db = await abrirBanco();

//Equivale a SELECT * FROM tarefas 
  final dados = await db.query('produto');


//O Sqlite devolve maps.
//Vamos transformar cada Map em um objeto tarefa
  return dados.map((item){
    return Produto(
      id: item['id'] as int,
      nome: item['nome']as String,
      categoria :item['categoria'] as String,
      quantidade :item['quantidade'] as int,
      preco :item['preco'] as int
    );
  }).toList();
}

// Future <void> atualizarStatus(Usuario usuario) async{
//   final db = await abrirBanco();

// //atualiza um registro
//   await db.update(
//     'tarefas',
//      {'concluida':tarefa.concluida ? 1 : 0 },

// //Definindo qual registro será atualizado
//    where: 'id = ?',

//    //id da tarefa q será atualizada
//    whereArgs: [
//     tarefa.id,
//    ]

//   );
// }

}