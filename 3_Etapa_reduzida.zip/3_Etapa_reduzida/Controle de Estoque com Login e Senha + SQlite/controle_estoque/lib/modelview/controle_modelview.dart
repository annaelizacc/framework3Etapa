import 'package:flutter/material.dart';
import '../models/produto.dart';
import '../models/usuario.dart';
import '../service/service_controle.dart';

class ControleViewModel extends ChangeNotifier {
  final TarefaService _service = TarefaService();

  List<Usuario> usuarios = [];
  List<Produto> produtos = [];

  // ================= USUÁRIOS =================

  Future<void> carregarUsuarios() async {
    usuarios = await _service.listarUsuario();
    notifyListeners();
  }

  Future<void> adicionarUsuario(Usuario usuario) async {
    await _service.inserirUsuario(usuario);
    await carregarUsuarios();
  }

  // ================= PRODUTOS =================

  Future<void> carregarProdutos() async {
    produtos = await _service.listarProdutos();
    notifyListeners();
  }
}

Future<void> adicionarProduto(Produto produto) async {
    await _service.inserirUsuario(produto);
    await carregarProdutos();
  }