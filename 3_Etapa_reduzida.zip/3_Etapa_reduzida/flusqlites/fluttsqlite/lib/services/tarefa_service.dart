import 'package:path/path.dart';

import 'package:sqflite/sqflite.dart';

import '../models/tarefa.dart';

class TarefaService {

Future<Database> abrirBanco() async {
  //DESCOBRE ONDE O DISPOSITIVO PERMITE SALVAR BANCO DE DADOS
  final caminhoBanco = await getDatabasesPath();

  print("LOCAL DO BANCO $caminhoBanco");

//JUNTA A PASTA ENCONTRADA COM NOME DO ARQUIVO
  final caminho = join(caminhoBanco, 'tarefas.db');
  print("BANCO COMPLETO: $caminho");

  return openDatabase(
  caminho, 
  version: 1,
  
  onCreate: (db, version) async{
    await db.execute(
       '''
        CREATE TABLE tarefas(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          titulo TEXT NOT NULL,
          concluida INTEGER NOT NULL
        )
       ''',
    );
  }
  );
}

Future <void> inserirTarefas(Tarefa tarefas) async{
  final db = await abrirBanco();
  //insere no banco de dados
  await db.insert('tarefas',{
    'titulos': tarefas.titulo,
    'concluida':tarefas.concluida ? 1:0,
   },
 );
}

Future<List<Tarefa>> listarTarefas() async{
  //abre o banco
  final db = await abrirBanco();

//Equivale a SELECT * FROM tarefas 
  final dados = await db.query('tarefas');


//O Sqlite devolve maps.
//Vamos transformar cada Map em um objeto tarefa
  return dados.map((item){
    return Tarefa(
      id: item['id'] as int,
      titulo: item['titulo']as String,
      concluida :item['concluida'] == 1
    );
  }).toList();
}

Future <void> atualizarStatus(Tarefa tarefa) async{
  final db = await abrirBanco();

//atualiza um registro
  await db.update(
    'tarefas',
     {'concluida':tarefa.concluida ? 1 : 0 },

//Definindo qual registro será atualizado
   where: 'id = ?',

   //id da tarefa q será atualizada
   whereArgs: [
    tarefa.id,
   ]

  );
}

}